Utils placeholder
