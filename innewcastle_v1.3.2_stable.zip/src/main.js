// Entry point
console.log('InNewcastle v1.3.2 stable starting...');
