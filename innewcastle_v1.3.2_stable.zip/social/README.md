Social modules placeholder
