# Setup Guide

1. Log in to Apify Console
2. Create New Actor → From .zip
3. Upload this file
4. Build and Run
