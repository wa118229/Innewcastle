Logs placeholder
