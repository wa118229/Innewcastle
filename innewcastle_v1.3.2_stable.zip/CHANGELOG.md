# InNewcastle v1.3.2 Stable

- Added Dockerfile for Apify compatibility
- Core structure maintained
